#pragma once
#include <stdexcept>
#include <string>
#include <vector>


class MyError : public std::runtime_error {
public:
    explicit MyError(const std::string& msg) : std::runtime_error(msg) {}
};



class MyThing {
public:
    explicit MyThing(int value = 0) : value_(value) {}

    // 멤버 메소드
    int increment(int delta) {
        if (delta == 0) {
            throw MyError("delta must be non-zero");
        }

        value_ += delta;
        return value_;
    }

    // const 멤버 함수 예시 1: 값 읽기
    int peek() const { return value_; }


    double sum_with(const std::vector<double>& data) const {
        double s = 0.0;
        for (double x : data) s += x;
        return s + static_cast<double>(value_);
    }


    // 정적 메소드
    static const char* version() {
        return "MyThing/1.0";
    }

    // getter / setter
    int get_value() const { return value_; }
    void set_value(int v) { value_ = v; }





private:
    int value_;
};