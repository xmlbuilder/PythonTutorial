import numpy as np
import mything

print("version:", mything.MyThing.version())  # "MyThing/2.0"

t = mything.MyThing(10)

# const 멤버 함수
print("peek:", t.peek())                       # 10
print("sum_with:", t.sum_with([1.5, 2.5]))     # 1.5+2.5+10 = 14.0

# 예외 변환 확인
try:
    t.increment(0)  # delta==0 -> C++ MyError 던짐 -> Python mything.MyError 로 변환
except mything.MyError as e:
    print("caught:", e)

# 정상 증가
print("increment:", t.increment(5))            # 15
print("value now:", t.value)                   # 15

# NumPy: 멤버 값(15)을 모든 원소에 더한 새 배열
arr = np.array([[1.0, 2.0],[3.0, 4.0]])
out = t.add_to_array(arr)
print("arr:\n", arr)
print("out:\n", out)     # 각 원소에 +15

# NumPy: 정적 메소드로 임의 스칼라 더하기
print(mything.MyThing.add_scalar(arr, 100.0))
