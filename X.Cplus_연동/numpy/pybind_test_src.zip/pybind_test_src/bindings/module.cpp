//
// Created by jhjeong on 2025-10-05.
//
#include <pybind11/pybind11.h>
#include <pybind11/stl.h>
#include <pybind11/numpy.h>     // NumPy array_t
#include "../include/MyThing.hpp"

namespace py = pybind11;


static py::array_t<double> add_scalar_to_array(py::array_t<double, py::array::c_style | py::array::forcecast> src, double val)
{
    // 요청(버퍼) 얻기
    py::buffer_info buf = src.request();
    if (buf.ndim < 1) {
        throw MyError("Input array must have at least 1 dimension");
    }

    // 동일 shape의 결과 배열 생성
    py::array_t<double> dst(buf.shape);
    py::buffer_info out = dst.request();

    // 총 원소 수 계산
    size_t count = 1;
    for (auto d : buf.shape) count *= static_cast<size_t>(d);

    // 포인터로 접근 (C-contiguous 보장)
    const double* pIn  = static_cast<const double*>(buf.ptr);
    double*       pOut = static_cast<double*>(out.ptr);

    for (size_t i = 0; i < count; ++i) {
        pOut[i] = pIn[i] + val;
    }
    return dst;
}
PYBIND11_MODULE(mything, m) {
    m.doc() = "pybind11 example with const methods, exception mapping, and NumPy interop";

    // C++ 예외를 Python 예외로 등록 (mything.MyError 로 노출)
    // 이 등록만으로 MyError가 발생하면 Python에서 같은 이름의 예외로 잡을 수 있습니다.
    static py::exception<MyError> ex(m, "MyError");

    py::class_<MyThing>(m, "MyThing", R"doc(
A demo class:
- has one member variable (value)
- a member method that can throw
- const methods
- a static method
- NumPy helpers bound as methods
)doc")
        // 생성자
        .def(py::init<int>(), py::arg("value") = 0)

        // 프로퍼티
        .def_property("value", &MyThing::get_value, &MyThing::set_value, "Internal integer value")

        // 멤버 메소드 (예외 발생 가능)
        .def("increment", &MyThing::increment, py::arg("delta"),
             "Increase value by delta (raises MyError if delta==0)")

        // const 멤버 함수들
        .def("peek", &MyThing::peek, "Return current value (const)")
        .def("sum_with", &MyThing::sum_with, py::arg("data"),
             "Return sum(data) + value (const)")

        // 정적 메소드
        .def_static("version", &MyThing::version, "Return library version")

        // NumPy: 멤버 값을 모든 원소에 더해 새 배열 반환 (불변)
        .def("add_to_array",
             [](const MyThing& self, py::array_t<double, py::array::c_style | py::array::forcecast> arr) {
                 return add_scalar_to_array(arr, static_cast<double>(self.peek()));
             },
             py::arg("array"),
             R"doc(Return a new numpy array where each element is increased by self.value.)doc")

        // NumPy: 주어진 스칼라를 모든 원소에 더해 새 배열 반환 (정적 도우미)
        .def_static("add_scalar",
             [](py::array_t<double, py::array::c_style | py::array::forcecast> arr, double v) {
                 return add_scalar_to_array(arr, v);
             },
             py::arg("array"), py::arg("value"),
             R"doc(Return a new numpy array where each element is increased by the scalar.)doc");
}